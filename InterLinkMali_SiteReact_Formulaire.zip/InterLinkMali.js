import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Phone, MessageCircle } from "lucide-react";

export default function InterLinkMali() {
  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans">
      <header className="bg-[#1E3A8A] text-white p-6 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">InterLink Mali</h1>
          <Button className="bg-white text-[#1E3A8A] hover:bg-gray-100">
            Contactez-nous
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 space-y-12">
        <section className="text-center">
          <h2 className="text-4xl font-bold mb-4">Nous connectons les entreprises au bon partenaire</h2>
          <p className="text-lg text-gray-600 mb-6">BTP, Énergie, Fourniture – trouvez votre solution avec InterLink Mali</p>
          <Button className="text-lg">Discuter sur WhatsApp</Button>
        </section>

        <section>
          <h3 className="text-2xl font-semibold mb-6">Nos Services</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              "Mise en relation BTP",
              "Mise en relation Énergie",
              "Recherche de Fournisseurs",
              "Suivi de partenariats",
              "Support personnalisé",
              "Conseil en prospection"
            ].map((service, i) => (
              <Card key={i} className="rounded-2xl shadow">
                <CardContent className="p-6">
                  <h4 className="text-lg font-semibold">{service}</h4>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="bg-gray-100 p-6 rounded-2xl">
          <h3 className="text-2xl font-semibold mb-4">Pourquoi choisir InterLink Mali ?</h3>
          <ul className="list-disc pl-6 text-gray-700 space-y-2">
            <li>+50 entreprises partenaires analysées</li>
            <li>Intermédiaire neutre et professionnel</li>
            <li>Réponse rapide & personnalisée</li>
            <li>Base de données stratégique</li>
          </ul>
        </section>

        <section>
          <h3 className="text-2xl font-semibold mb-4">Contact</h3>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Phone className="text-[#1E3A8A]" /> <span>+223 74 00 00 00</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="text-[#1E3A8A]" /> <span>contact@interlink.ml</span>
            </div>
            <div className="flex items-center gap-2">
              <MessageCircle className="text-[#1E3A8A]" /> <span>WhatsApp : +223 74 00 00 00</span>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#1E3A8A] text-white text-center py-4 mt-12">
        © 2025 InterLink Mali – Tous droits réservés
      </footer>
    </div>
  );
}